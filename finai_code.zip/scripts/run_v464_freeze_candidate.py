from __future__ import annotations

import json

from finai.application.services.v464_learning_factory import (
    build_v464_learning_service,
)
from finai.core.config import get_settings


def main() -> None:
    service = build_v464_learning_service(
        settings=get_settings(),
    )

    result = service.freeze_candidate(

    )

    print(
        json.dumps(
            result,
            indent=2,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
